import FlatListSlider from './src/FlatListSlider';
import Indicator from './src/Indicator';

export { FlatListSlider, Indicator };