// Prop type definitions required for ambiguities and deficiencies in the
// prop-types package.
// These may need to be tweaked as prop types are improved.

import PropTypes from 'prop-types';

export const stylePropType = PropTypes.any;
